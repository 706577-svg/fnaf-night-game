# Animatronic Place — Final (Upload-Ready)

This repository contains a browser-playable FNaF-style demo:
- First-person exploration (W/A/S/D + mouse)
- Large modular map (~25,000 m²)
- Roaming animatronic (patrols and can chase)
- Collectible power cells to refill flashlight
- Procedural ambient audio (fan hum, creaks, flicker)
- Doors (animated), flashlight, and UI

## Controls
- Click **Start**, then click inside the canvas to lock the mouse.
- W/A/S/D — Move
- Mouse — Look
- F — Toggle flashlight
- E — Pick up items (power cells)
- Q — Toggle a random door (for testing)

## How to publish with GitHub Pages
1. Create a new repository on GitHub (public).
2. Upload `index.html` to the repository root.
3. In **Settings → Pages**, set **Source** to `main` branch and `/ (root)`.
4. Save and wait ~30–60 seconds. Your site will be at:
   `https://yourusername.github.io/repo-name/`

## Notes & editing
- The game is intentionally self-contained (no external asset files). You can replace procedural audio with real sound files by loading them into the code.
- To reduce map size for performance, change `COLS`, `ROWS`, and `CELL` values at the top of `index.html`.
- This is a demo build — if you want:
  - Better 3D models (GLTF) for animatronics
  - Real audio samples and music
  - Save/load, minimap, menu screens
  - Multiplayer or advanced AI
  I can add them in the next iteration.

Enjoy — upload `index.html` to GitHub Pages and share the link!